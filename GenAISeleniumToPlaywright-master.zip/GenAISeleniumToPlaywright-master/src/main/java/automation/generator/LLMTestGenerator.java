package automation.generator;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

public class LLMTestGenerator {

    private static final String LLM_API_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final String API_KEY = "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";

    public String generateTestCases(String codeDetails) {
        if (codeDetails == null || codeDetails.isEmpty()) {
            return "No valid Selenium Code available to generate test cases.";
        }
        String userPrompt = "Generate Playwright code for the Selenium code attached"
                            + codeDetails;
        try {
            List<Map<String, String>> messages = new ArrayList<>();
            Map<String, String> systemMessage = new HashMap<>();
            systemMessage.put("role", "system");
            systemMessage.put("content", "You are a helpful assistant that generates Playwright code for Selenium tests. "
            		+ "Your response must contain only Selenium Java code enclosed in a single code block using triple backticks (```java ... ```). "
            		+ "- Do not include any additional text explanations. "
                    + "- Be a complete and executable Java class. "
                    + "- Use only standard and correct imports (e.g., org.testng.Assert, io.restassured.RestAssured). "
            		+ "- in the code get method will have the url to navigate"
                    + "- all locators will be under findElementById method"
            		+ "- convert all steps into Playwright code"
            		+ "- Add package as automation.tests"
            		+ "- Write comments on the code");
   
            messages.add(systemMessage);
            Map<String, String> userMessage = new HashMap<>();
            userMessage.put("role", "user");
            userMessage.put("content", userPrompt);
            messages.add(userMessage);
            Map<String, Object> payload = new HashMap<>();
            payload.put("model", "deepseek-r1-distill-llama-70b");
            payload.put("messages", messages);
            payload.put("temperature", 0.2);
            payload.put("max_tokens", 1500);
            ObjectMapper mapper = new ObjectMapper();
            String requestBody = mapper.writeValueAsString(payload);
            return callLLMApi(requestBody);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error building JSON payload: " + e.getMessage();
        }
    }

    private String callLLMApi(String requestBody) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(LLM_API_URL);
            request.setHeader("Content-Type", "application/json");
            request.setHeader("Authorization", "Bearer " + API_KEY);
            request.setEntity(new StringEntity(requestBody));
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                return EntityUtils.toString(response.getEntity());
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error calling LLM API: " + e.getMessage();
        }
    }
}
