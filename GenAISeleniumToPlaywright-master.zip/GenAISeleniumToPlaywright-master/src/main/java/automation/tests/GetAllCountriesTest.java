package automation.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import java.io.PrintStream;

public class GetAllCountriesTest {

    @BeforeMethod
    public void setUp() {
        // Setting the base URI for all tests
        RestAssured.baseURI = "https://restcountries.com/v3.1";
    }

    @Test
    public void testGetAllCountries() {
        // Sending a GET request to /all endpoint
        Response response = given()
                .when()
                .get("/all");

        // Printing the response body
        PrintStream out = System.out;
        out.println("Response Body: " + response.body().prettyPrint());

        // Asserting the status code
        assertEquals(response.getStatusCode(), 200, "Status code should be 200");

        // Asserting the content type
        assertEquals(response.contentType(), "application/json");
        
        // Asserting response body is not null
        assertEquals(response.body() != null, true, "Response body should not be null");
    }
}