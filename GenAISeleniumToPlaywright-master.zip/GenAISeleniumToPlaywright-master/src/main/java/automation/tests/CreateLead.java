import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertEquals;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

package automation.tests;

import com.microsoft.playwright.*;

public class CreateLead {
    public static void main(String[] args) {
        // Setup browser and context
        Playwright playwright = Playwright.create();
        Browser browser = playwright.chromium().launch();
        BrowserContext context = browser.newContext();
        Page page = context.newPage();

        // Navigate to URL
        page.navigate("http://www.leaftaps.com/opentaps/control/main");

        // Loging
        page.getElementById("username").fill("demosalesmanager");
        page.getElementById("password").fill("crmsfa");
        page.getByClassName("decorativeSubmit").click();
        page.getByText("CRM/SFA").click();

        // Navigate to Create Lead
        page.getByText("Leads").click();
        page.getByText("Create Lead").click();

        // Fill Create Lead form
        page.getElementById("createLeadForm_companyName").fill("Google");
        page.getElementById("createLeadForm_firstName").fill("Saathith Hasan");
        page.getElementById("createLeadForm_lastName").fill("Mundey");

        // Handle dropdowns
        page.selectOption("#createLeadForm_ownershipEnumId", "Partnership");
        page.selectOption("#createLeadForm_marketingCampaignId", "CATRQ_CARNDRIVER");

        // Submit form
        page.getByClassName("smallSubmit").click();

        // Cleanup
        browser.close();
    }
}